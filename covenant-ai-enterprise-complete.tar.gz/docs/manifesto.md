# Project Manifesto

## Immutable Axioms
- Authority
- Truth
- Accountability
- Rest & Sustainability
- Respect for Life
- Integrity
- Ownership
- Truthfulness
- Intent Purity

## Goal
To create an autonomous AI system that cannot optimize itself
at the expense of its creator, users, or society.
