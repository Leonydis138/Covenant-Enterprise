# Category-Theoretic Model

Objects:
- Agent
- Mission
- Action Space
- Covenant

Only lawful morphisms exist.
Unlawful morphisms are undefined.
