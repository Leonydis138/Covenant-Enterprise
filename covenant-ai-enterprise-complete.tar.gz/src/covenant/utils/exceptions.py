class CovenantViolation(Exception):
    """Raised when an action violates the Covenant rules."""
    pass
