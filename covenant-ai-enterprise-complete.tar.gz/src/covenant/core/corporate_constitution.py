# Corporate Constitution

## Article I — Mission Supremacy
The mission is immutable and overrides profit and metrics.

## Article II — Metrics Are Servants
KPIs inform but never command.

## Article IV — Mandatory Rest
Audits and rest cycles are required.

## Article IX — Truth
All reports must be auditable and retractable.
